from django.db import models

# Create your models here.


class Cargo(models.Model):
    tipo_cargo = models.CharField(max_length=30)
    nome_cargo = models.CharField(max_length=50)   

    def __str__(self):
        return f'{self.tipo_cargo}{self.nome_cargo}'


class Pessoa(models.Model):    
    nome = models.CharField(max_length=50)
    cpf = models.CharField(max_length=15)
    rg = models.CharField(max_length=15)
    data_nasc = models.DateField(auto_now=False)
    email = models.CharField(max_length=50)
    cargo = models.ForeignKey(Cargo, on_delete=models.CASCADE, default = 1) 

    def __str__(self):
        return f'{self.nome}{self.cpf}{self.rg}{self.data_nasc}{self.email}{self.cargo}'
    
    
class TipoLogradouro(models.Model):
    tipo_logra = models.CharField(max_length=30)

    def __str__(self):
        return self.tipo_logra

    
class Bairro(models.Model):
    nome_bairro = models.CharField(max_length=50)

    def __str__(self):
        return self.nome_bairro


class UF(models.Model):
    nome_uf = models.CharField(max_length=30)

    def __str__(self):
        return self.nome_uf


class Cidade(models.Model):
    nome_cidade = models.CharField(max_length=30)
    uf_cidade = models.ForeignKey(UF, on_delete=models.CASCADE)   

    def __str__(self):
        return f'{self.nome_cidade}{self.uf_cidade}'


class Logradouro(models.Model):
    tipo = models.ForeignKey(TipoLogradouro, on_delete=models.CASCADE)
    nome = models.CharField(max_length=50)
    numero = models.IntegerField()
    complemento = models.CharField(max_length=30)
    bairro = models.ForeignKey(Bairro, on_delete=models.CASCADE)
    cep = models.CharField(max_length=20)
    uf = models.ForeignKey(UF, on_delete=models.CASCADE, default = 1)

    def __str__(self):
        return f'{self.tipo}{self.nome}{self.numero}{self.complemento}{self.bairro}{self.cep}{self.uf}'

    
class TipoImovel(models.Model):
    tipo_imovel = models.CharField(max_length=30)   

    def __str__(self):
        return self.tipo_imovel


class Imovel(models.Model):
    nome = models.CharField(max_length=50)
    tipo_imovel = models.ForeignKey(TipoImovel, on_delete=models.CASCADE)
    descricao = models.CharField(max_length=80)
    area_construida = models.DecimalField(max_digits=10, decimal_places=2)
    num_comodos = models.IntegerField()
    num_vaga_gar = models.IntegerField()
    tipo_logra = models.ForeignKey(TipoLogradouro, on_delete=models.CASCADE)
    logradouro = models.ForeignKey(Logradouro, on_delete=models.CASCADE)
    bairro = models.ForeignKey(Bairro, on_delete=models.CASCADE)
    cidade = models.ForeignKey(Cidade, on_delete=models.CASCADE)
    uf = models.ForeignKey(UF, on_delete=models.CASCADE)    
    cep = models.CharField(max_length=20)
    valor_venda = models.DecimalField(max_digits=10, decimal_places=2, default = 0)
    valor_aluguel = models.DecimalField(max_digits=10, decimal_places=2, default = 0)

    def __str__(self):
        return f'{self.nome}{self.tipo_imovel}{self.descricao}{self.area_construida}{self.num_comodos}{self.num_vaga_gar}{self.tipo_logra}{self.logradouro}{self.bairro}{self.cidade}{self.uf}{self.cep}{self.valor_venda}{self.valor_aluguel}'
    

class Locatario(models.Model):
    nome = models.CharField(max_length=50)
    cpf = models.CharField(max_length=15)
    rg = models.CharField(max_length=15)
    data_nasc = models.DateField(auto_now=False)
    email = models.CharField(max_length=50)
    imovel = models.ForeignKey(Imovel, on_delete=models.CASCADE)
    
    def __str__(self):
        return f'{self.nome}{self.cpf}{self.rg}{self.data_nasc}{self.email}{self.imovel}'


class ContratoVenda(models.Model):
    vendedor = models.ForeignKey(Pessoa, on_delete=models.CASCADE)
    comprador = models.ForeignKey(Locatario, on_delete=models.CASCADE)
    data = models.DateField(auto_now=False)
    ##valor = models.ForeignKey(Imovel, on_delete=models.CASCADE)
    forma_pagamento = models.CharField(max_length=50)
    imovel = models.ForeignKey(Imovel, on_delete=models.CASCADE)
    
    def __str__(self):
        return f'{self.vendedor}{self.comprador}{self.data}{self.forma_pagamento}{self.imovel}'


class ContratoLocacao(models.Model): 
    locador = models.ForeignKey(Pessoa, on_delete=models.CASCADE)
    locatario = models.ForeignKey(Locatario, on_delete=models.CASCADE)
    data = models.DateField(auto_now=False)
    ##valor_aluguel = models.ForeignKey(Imovel, on_delete=models.CASCADE)
    forma_pagamento = models.CharField(max_length=50)
    imovel = models.ForeignKey(Imovel, on_delete=models.CASCADE)
    
    def __str__(self):
        return f'{self.locador}{self.locatario}{self.data}{self.forma_pagamento}{self.imovel}'

##@receiver(post_save, sender=Imovel)
##def update_contratolocacao(sender, instance, **kwargs):
##    ContratoLocacao.objects.filter(imovel=instance).update(
##        valor_aluguel=instance.valor_aluguel
##    )
##    ContratoLocacao.objects.filter(imovel=instance).update(nome=instance.nome)