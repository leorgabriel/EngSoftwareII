from django.shortcuts import render
from . models import*
# Create your views here.

def consulta_imovel(request):
    consulta_filmes = {
        'consulta_imovels': Imovel.objects.all()
        }
    return render(request, 'consulta/consulta_imovel.html', consulta_filmes)

def consulta_locatario(request):
    consulta_series = {
        'consulta_locatarios': Locatario.objects.all()
        }
    return render(request, 'consulta/consulta_locatario.html', consulta_series)

def consulta_pessoa(request):
    consulta_direatores = {
        'consulta_pessoas': Pessoa.objects.all()
        }
    return render(request, 'consulta/consulta_pessoa.html', consulta_direatores)


        





